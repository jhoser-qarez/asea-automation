// tests/e2e/virtual-office-markets.spec.ts
import { test } from "@playwright/test";
import { LoginPage } from "../../pages/LoginPage";
import { UserMenuPage } from "../../pages/UserMenuPage";
import { VirtualOfficePage } from "../../pages/VirtualOffice/VirtualOfficePage";
import { VOHeaderPage } from "../../pages/VirtualOffice/VOHeaderPage";
import { users } from "../../fixtures/credentials";

interface ProjectMetadata {
  env?: string;
  voPort?: string;
}

test.describe("Virtual Office - Cambio de mercado y carga de páginas", () => {
  function getConfig(projectName: string, metadata?: ProjectMetadata) {
    const env =
      metadata?.env === "stage" || metadata?.env === "live"
        ? metadata.env
        : projectName === "stage"
          ? "stage"
          : "live";
    const voPort = metadata?.voPort;
    const user = env === "stage" ? users.valid : users.validLive;
    return { env, voPort, user };
  }

  test("Recorrer todos los mercados disponibles y verificar secciones", async ({
    page,
  }) => {
    test.setTimeout(3_600_000); // 1 hora (50 mercados × N secciones cada uno)

    const project = test.info().project;
    const config = getConfig(project.name, project.metadata as ProjectMetadata);

    const loginPage = new LoginPage(page);
    const userMenu = new UserMenuPage(page);

    // Login
    await loginPage.gotoByEnv(config.env as "stage" | "live");
    await loginPage.login(config.user.username, config.user.password);
    await loginPage.verifyLoginSuccess(config.user.username);

    // Abrir VO
    const voPage = await userMenu.goToVirtualOffice(config.voPort);
    const vo = new VirtualOfficePage(voPage);
    const header = new VOHeaderPage(voPage);

    await vo.closePromoBannerIfExists();
    await vo.closeWelcomeModalIfExists();
    await header.verifyHeaderVisible();

    // Obtener TODOS los mercados disponibles en este entorno
    console.log("\n🔍 Obteniendo lista de mercados disponibles...");
    const allMarkets = await header.getAllMarkets();

    if (allMarkets.length === 0) {
      throw new Error("No se encontraron mercados para probar");
    }

    console.log(`\n🚀 Iniciando prueba de ${allMarkets.length} mercados...\n`);

    const failedMarkets: { market: string; error: string }[] = [];
    let currentIndex = 0;

    for (const marketName of allMarkets) {
      currentIndex++;
      await test.step(`[${currentIndex}/${allMarkets.length}] Probar mercado: ${marketName}`, async () => {
        try {
          console.log(`\n🌍 === Probando mercado: ${marketName} ===`);

          // Cambiar al mercado
          await header.changeToMarket(marketName);

          // Esperar estabilización
          await voPage.waitForLoadState("networkidle", { timeout: 30000 });
          await vo.closePromoBannerIfExists();
          await vo.closeWelcomeModalIfExists();

          // Verificar que el cambio fue exitoso
          await header.verifyCurrentMarket(marketName);

          // Extraer secciones del header horizontal y la barra lateral
          const headerLinks = await vo.extractHeaderLinks();
          const sidebarLinks = await vo.extractSidebarLinks();
          const allSections = [...headerLinks, ...sidebarLinks];

          if (allSections.length === 0) {
            console.log(`⚠️ No se encontraron secciones para "${marketName}"`);
          } else {
            console.log(`🗂️ Verificando ${allSections.length} secciones (${headerLinks.length} header + ${sidebarLinks.length} sidebar) para "${marketName}"...`);
            for (const link of allSections) {
              await vo.navigateToSectionByUrl(link.url, link.text);
            }
          }

          console.log(`✅ Mercado "${marketName}" verificado correctamente`);
        } catch (error) {
          console.log(`❌ Falló el mercado "${marketName}"`);
          await voPage
            .screenshot({
              path: `test-results/failed-market-${marketName.replace(/[^a-zA-Z0-9]/g, "_")}.png`,
              fullPage: true,
            })
            .catch(() => {});
          failedMarkets.push({ market: marketName, error: String(error) });

          // Volver al home del VO para continuar — todo protegido para no romper el loop
          try {
            const currentUrl = voPage.url();
            await voPage.goto(
              currentUrl.split("/Private/")[0] + "/Private/overview/Home.aspx",
              { waitUntil: "domcontentloaded", timeout: 30000 },
            );
            await vo.closePromoBannerIfExists();
          } catch {
            console.log(`⚠️ No se pudo recuperar el estado tras el fallo en "${marketName}"`);
          }
        }
      });
    }

    // Reportar resultados finales
    console.log(`\n📊 RESULTADOS FINALES:`);
    console.log(`   Total mercados probados: ${allMarkets.length}`);
    console.log(`   Exitosos: ${allMarkets.length - failedMarkets.length}`);
    console.log(`   Fallidos: ${failedMarkets.length}`);

    if (failedMarkets.length > 0) {
      console.log(`\n❌ Mercados con error:`);
      failedMarkets.forEach(({ market, error }) => {
        console.log(`   - ${market}: ${error.substring(0, 100)}`);
      });
      throw new Error(
        `${failedMarkets.length} mercados presentaron errores: ${failedMarkets.map((m) => m.market).join(", ")}`,
      );
    } else {
      console.log("\n✅ TODOS los mercados cargaron correctamente");
    }
  });

  test("Verificar mercados agrupados por continente", async ({ page }) => {
    const project = test.info().project;
    const config = getConfig(project.name, project.metadata as ProjectMetadata);

    const loginPage = new LoginPage(page);
    const userMenu = new UserMenuPage(page);
    const voPage = await userMenu.goToVirtualOffice(config.voPort);

    const vo = new VirtualOfficePage(voPage);

    await loginPage.gotoByEnv(config.env as "stage" | "live");
    await loginPage.login(config.user.username, config.user.password);
    await loginPage.verifyLoginSuccess(config.user.username);

    const header = new VOHeaderPage(voPage);

    await vo.closePromoBannerIfExists();
    await vo.closeWelcomeModalIfExists();

    const marketsByZone = await header.getMarketsByZone();

    console.log("\n📊 MERCADOS POR CONTINENTE:");
    console.log(`\n🌎 The Americas (${marketsByZone.americas.length}):`);
    marketsByZone.americas.forEach((m) => console.log(`   - ${m}`));
    console.log(`\n🌍 Europe (${marketsByZone.europe.length}):`);
    marketsByZone.europe.forEach((m) => console.log(`   - ${m}`));
    console.log(`\n🌏 Asia Pacific (${marketsByZone.asiaPacific.length}):`);
    marketsByZone.asiaPacific.forEach((m) => console.log(`   - ${m}`));

    // Guardar en archivo para referencia
    const fs = require("fs");
    fs.writeFileSync(
      "test-results/markets-by-zone.json",
      JSON.stringify(marketsByZone, null, 2),
    );
    console.log("\n📁 Lista guardada en: test-results/markets-by-zone.json");
  });
});
