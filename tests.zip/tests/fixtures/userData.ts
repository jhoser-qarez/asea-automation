export const userInfo = {
  basic: {
    email: "jhoserjuarez86480064@test.com",
    firstName: "Jhoser",
    lastName: "TestEnroll",
    phone: "9086498182",
  },
  address: {
    address1: "65 South 980 West",
    address2: "Apt 4B",
    city: "orem",
    state: "Utah",
    zip: "84018",
  },
  shipping: {
    order: "standard" as "standard" | "usps",
    subscription: "standard" as "standard" | "usps",
  },
  card: {
    name: "Test US Account",
    number: "5454545454545454",
    expMonth: "03",
    expYear: "2030",
    cvv: "123",
  },
};

export const userInfoLive = {
  basic: {
    email: "ppadilla2@peruslab.com",
    firstName: "Test US",
    lastName: "Account",
    phone: "2142709857",
  },
  address: {
    address1: "65 South 980 West",
    address2: "Apt 4B",
    city: "orem",
    state: "Utah",
    zip: "84018",
  },
  shipping: {
    order: "standard" as "standard" | "usps",
    subscription: "standard" as "standard" | "usps",
  },
  card: {
    name: "Test US Account",
    number: "5454545454545454", //4141123456784999
    expMonth: "03",
    expYear: "2030",
    cvv: "123",
  },
};
