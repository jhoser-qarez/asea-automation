export const users = {
  //login shop en stage
  valid: {
    username: "1800974310",
    password: "TestEnroll!234",
  },
   //login shop en live
  validLive: {
    username: "1500131292",
    password: "TestAsea!234",
  },
  invalid: {
    username: "usuario_falso",
    password: "password_falso",
  },

  // ✅ Credenciales Oscar
  oscar: {
    username: "jjuarez@peruslab.com",
    password: "Aseaperu@2024.",
  },
  oscarLive: {
    username: "jjuarez@peruslab.com",
    password: "Aseaperu!2024",
  },
  
};
