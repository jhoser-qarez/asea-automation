export const users = {
  valid: {
    username: "1800965901",
    password: "Aseaperu@2024.",
  },
  invalid: {
    username: "usuario_falso",
    password: "password_falso",
  },

  // ✅ Credenciales Oscar
  oscar: {
    username: "jjuarez@peruslab.com",
    password: "Aseaperu@2024.",
  },
};
