export const userInfo = {
  basic: {
    email: "jhosertest1@test.com",
    firstName: "Jhoser",
    lastName: "Juarez",
    phone: "9000000001",
  },
  address: {
    address1: "65 South 980 West",
    address2: "Apt 4B",
    city: "orem",
    state: "Utah",
    zip: "84018",
  },
  shipping: {
    order: "standard" as "standard" | "usps",
    subscription: "standard" as "standard" | "usps",
  },

  card: {
    name: "Test US Account",
    number: "5454545454545454",
    expMonth: "03",
    expYear: "2030",
    cvv: "123",
  },
};
